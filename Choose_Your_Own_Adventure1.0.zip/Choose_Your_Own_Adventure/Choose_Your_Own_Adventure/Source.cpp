#include <iostream>
#include <math.h>
#include <iomanip>
#include <string>
#include <time.h> 
#include "Player.h"
#include "Functions.h"
#include "Art.h"
using namespace std;

int main()
{
	
	begin_Game();

	return 0;
}



